from __future__ import absolute_import
from _plotly_future_ import _chart_studio_error

_chart_studio_error("plotly.chunked_requests")
